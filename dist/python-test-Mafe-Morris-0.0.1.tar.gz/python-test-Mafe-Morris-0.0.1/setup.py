from setuptools import setup, find_packages

requirements = [
    "numoy",
    "abc"]

setup(
    name="python-test-Mafe-Morris",
    version="0.0.1",
    author="Maria Fernanda Morris",
    author_email="mafemorris99@gmail.com",
    description="Basic lens and sensor simulator",
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    install_requires = requirements,
    package_dir={"": "camera_simulator"},
    packages=find_packages(where="camera_simulator"),
    python_requires=">=3.6",
)