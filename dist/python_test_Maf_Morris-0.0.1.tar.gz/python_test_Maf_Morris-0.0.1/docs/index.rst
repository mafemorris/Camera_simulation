.. Camera_simulator documentation master file, created by
   sphinx-quickstart on Sat Feb 19 22:41:48 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Camera_simulator's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. include:: camera_simulator.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
