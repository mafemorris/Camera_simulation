""" Camera simulator with sensor and lens."""
